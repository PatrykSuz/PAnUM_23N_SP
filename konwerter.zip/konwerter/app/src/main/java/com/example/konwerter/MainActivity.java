package com.example.konwerter;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputText;
    private TextView result;
    private Button convertButton;
    private Spinner typeSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputEditText);
        result = findViewById(R.id.resultTextView);
        convertButton = findViewById(R.id.convertButton);
        typeSpinner = findViewById(R.id.conversionTypeSpinner);


        String[] conversionTypes = getResources().getStringArray(R.array.conversion_types);
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, conversionTypes);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(spinnerAdapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertValue();
            }
        });
    }

    private void convertValue() {
        String inputValueStr = inputText.getText().toString().trim();

        if (inputValueStr.isEmpty()) {
            Toast.makeText(this, "Wpisz wartość", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double inputValue = Double.parseDouble(inputValueStr);
            String selectedConversion = typeSpinner.getSelectedItem().toString();
            double result;

            switch (selectedConversion) {
                case "Złotówki na Euro":
                    result = inputValue * 0.23;
                    break;
                case "Centymetry na Cale":
                    result = inputValue * 0.39;
                    break;
                case "Stopnie Celsiusza na Stopnie Fahrenheita":
                    result = (inputValue * 9/5) + 32;
                    break;
                case "Kilometry na Mile":
                    result = inputValue * 0.621;
                    break;
                default:
                    result = 0;
            }
            this.result.setText(String.format("%.2f", result));

        } catch (NumberFormatException e) {

            Toast.makeText(this, "Niepoprawne dane", Toast.LENGTH_SHORT).show();
        }
    }
}
