package com.example.stoper_i_minutnik;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private int stopwatchSeconds = 0;
    private int stopwatchHundredths = 0;
    private boolean isRunningStopwatch = false;


    private int timerMinutes = 0;
    private int timerSeconds = 0;
    private int timerTenths = 0;
    private boolean isRunningTimer = false;
    private boolean isTimerStarted = false;


    private TextView stopwatchTextView;
    private TextView timerTextView;

    private Handler stopwatchHandler;
    private Handler timerHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        stopwatchTextView = findViewById(R.id.stopwatch);
        timerTextView = findViewById(R.id.timer);


        stopwatchHandler = new Handler();
        timerHandler = new Handler();

        if (savedInstanceState != null) {
            stopwatchSeconds = savedInstanceState.getInt("stopwatchSeconds");
            stopwatchHundredths = savedInstanceState.getInt("stopwatchHundredths");
            isRunningStopwatch = savedInstanceState.getBoolean("isRunningStopwatch");
            timerMinutes = savedInstanceState.getInt("timerMinutes");
            timerSeconds = savedInstanceState.getInt("timerSeconds");
            timerTenths = savedInstanceState.getInt("timerTenths");
            isRunningTimer = savedInstanceState.getBoolean("isRunningTimer");
            isTimerStarted = savedInstanceState.getBoolean("isTimerStarted");
        }

        runStopwatch();
        runCountdownTimer();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("stopwatchSeconds", stopwatchSeconds);
        outState.putInt("stopwatchHundredths", stopwatchHundredths);
        outState.putBoolean("isRunningStopwatch", isRunningStopwatch);
        outState.putInt("timerMinutes", timerMinutes);
        outState.putInt("timerSeconds", timerSeconds);
        outState.putInt("timerTenths", timerTenths);
        outState.putBoolean("isRunningTimer", isRunningTimer);
        outState.putBoolean("isTimerStarted", isTimerStarted);
    }

    public void onClickStartStopwatch(View view) {
        isRunningStopwatch = true;
    }

    public void onClickStopStopwatch(View view) {
        isRunningStopwatch = false;
    }

    public void onClickResetStopwatch(View view) {
        isRunningStopwatch = false;
        stopwatchSeconds = 0;
        stopwatchHundredths = 0;
    }

    private void runStopwatch() {
        stopwatchHandler.post(new Runnable() {
            @Override
            public void run() {
                int hours = stopwatchSeconds / 3600;
                int minutes = (stopwatchSeconds % 3600) / 60;
                int seconds = stopwatchSeconds % 60;
                String time = String.format(Locale.US, "%d:%02d:%02d.%d", hours, minutes, seconds, stopwatchHundredths);
                stopwatchTextView.setText(time);
                if (isRunningStopwatch) {
                    stopwatchHundredths++;
                    if (stopwatchHundredths == 10) {
                        stopwatchSeconds++;
                        stopwatchHundredths = 0;
                    }
                }
                stopwatchHandler.postDelayed(this, 100);
            }
        });
    }

    // Timer methods
    public void onClickStartTimer(View view) {
        if (!isTimerStarted) {
            EditText minutesText = findViewById(R.id.minutes);
            timerMinutes = Integer.parseInt(minutesText.getText().toString());
            EditText secondsText = findViewById(R.id.seconds);
            timerSeconds = Integer.parseInt(secondsText.getText().toString());
        }
        isTimerStarted = true;
        isRunningTimer = true;
    }

    public void onClickStopTimer(View view) {
        isRunningTimer = false;
    }

    public void onClickResetTimer(View view) {
        isRunningTimer = false;
        isTimerStarted = false;
        timerTextView.setText(R.string.timer_default);
        timerTenths = 0;
        timerSeconds = 0;
        timerMinutes = 0;
    }

    private void runCountdownTimer() {
        timerHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isRunningTimer) {
                    if (timerTenths == 0) {
                        if (timerSeconds == 0) {
                            if (timerMinutes == 0) {
                                isRunningTimer = false;
                                return;
                            } else {
                                timerMinutes--;
                                timerSeconds = 59;
                                timerTenths = 9;
                            }
                        } else {
                            timerSeconds--;
                            timerTenths = 9;
                        }
                    } else {
                        timerTenths--;
                    }
                }
                String time = String.format(Locale.US, "%02d:%02d.%d", timerMinutes, timerSeconds, timerTenths);
                timerTextView.setText(time);
                timerHandler.postDelayed(this, 100);
            }
        });
    }
}
