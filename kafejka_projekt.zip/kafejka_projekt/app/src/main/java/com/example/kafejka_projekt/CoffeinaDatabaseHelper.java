package com.example.kafejka_projekt;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class CoffeinaDatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "coffeina";
    private static final int DB_VERSION = 2;

    CoffeinaDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        updateMyDatabase(db, 0, DB_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateMyDatabase(db, oldVersion, newVersion);
    }

    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            db.execSQL("CREATE TABLE DRINK (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "NAME TEXT, "
                    + "DESCRIPTION TEXT, "
                    + "IMAGE_RES_ID INTEGER);");
            insertDrink(db, "Latte", "Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte);
            insertDrink(db, "Cappuccino", "Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappuccino);
            insertDrink(db, "Espresso", "Czarna kawa ze świeżo mielonych ziaren najwyższej jakości.", R.drawable.espresso);
        }
        if (oldVersion < 2) {
            insertDrink(db, "Przelew", "Czarna kawa parzona metodą przelewową z mieszanki ziaren arabiki i robusty.", R.drawable.filter);
        }
    }

    private static void insertDrink(SQLiteDatabase db, String name, String description, int resourceId) {
        ContentValues drinkValues = new ContentValues();
        drinkValues.put("NAME", name);
        drinkValues.put("DESCRIPTION", description);
        drinkValues.put("IMAGE_RES_ID", resourceId);
        db.insert("DRINK", null, drinkValues);
    }

    private void logTableContents(SQLiteDatabase db) {
        Cursor cursor = db.query("DRINK",
                new String[]{"_id", "NAME", "DESCRIPTION", "IMAGE_RES_ID"},
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Log.d("DB_DEBUG", "ID: " + cursor.getInt(0) +
                        ", Name: " + cursor.getString(1) +
                        ", Description: " + cursor.getString(2) +
                        ", ImageResId: " + cursor.getInt(3));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
