package com.example.kafejka_projekt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class OrderActivity extends AppCompatActivity {

    private EditText emailEditText;
    private Button sendButton;
    private static final String PREFS_NAME = "OrderName";
    private static final String KEY_ORDER = "Order";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_order);

        emailEditText = findViewById(R.id.email_edit_text);
        sendButton = findViewById(R.id.send_order_button);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                if (email.isEmpty()) {
                    Toast.makeText(OrderActivity.this, "Podaj swój adres e-mail", Toast.LENGTH_SHORT).show();
                } else {

                    String orderDetails = getOrderDetails();
                    sendEmailConfirmation(email, orderDetails);
                    clearOrder();

                }
            }
        });
    }

    private String getOrderDetails() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(KEY_ORDER, "Nie wybrano produktów.");
    }

    private void clearOrder() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_ORDER);
        editor.apply();
    }

    private void sendEmailConfirmation(String email, String orderDetails) {

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Kafeteria. Twoje zamówienie.");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Cześć! Przyjęliśmy Twoje zamówienie.\n\nZamówione pozycje:\n" + orderDetails);

        try {
            startActivity(Intent.createChooser(emailIntent, "Wybierz aplikację"));
        } catch (android.content.ActivityNotFoundException ex) {

            Toast.makeText(OrderActivity.this, "Na Twoim urządzeniu nie znaleziono aplikacji do wysyłania e-maili.", Toast.LENGTH_SHORT).show();
        }
    }
}
