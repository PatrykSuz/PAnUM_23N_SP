package com.example.kafejka_projekt;

import android.app.Activity;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DrinkActivity extends Activity {
    public static final String EXTRA_DRINKID = "drinkId";
    private static final String ORDER_NAMES = "OrderNames";
    private static final String KEY_ORDER = "Order";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);

        int drinkId = (Integer) getIntent().getExtras().get(EXTRA_DRINKID);
        SQLiteOpenHelper coffeinaDatabaseHelper = new CoffeinaDatabaseHelper(this);

        try {

            SQLiteDatabase db = coffeinaDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query("DRINK",
                    new String[]{"NAME", "DESCRIPTION", "IMAGE_RES_ID"},
                    "_id = ?",
                    new String[]{Integer.toString(drinkId)},
                    null, null, null);

            if (cursor.moveToFirst()) {
                String nameText = cursor.getString(0);

                String descriptionText = cursor.getString(1);

                int photoId = cursor.getInt(2);

                TextView name = findViewById(R.id.name);
                name.setText(nameText);

                TextView description = findViewById(R.id.description);

                description.setText(descriptionText);



                ImageView photo = findViewById(R.id.photo);

                photo.setImageResource(photoId);



                photo.setContentDescription(nameText);

                Button addToOrderButton = findViewById(R.id.order_button);

                addToOrderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addToOrder(nameText);
                    }
                });
            }

            cursor.close();
            db.close();


        } catch (SQLiteException e) {
            Toast toast = Toast.makeText(this, "Wystapił błąd. Baza niedostępna", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    private void addToOrder(String drinkName) {
        SharedPreferences prefs = getSharedPreferences(ORDER_NAMES, MODE_PRIVATE);


        SharedPreferences.Editor editor = prefs.edit();

        String currentOrder = prefs.getString(KEY_ORDER, "");

        if (!currentOrder.isEmpty()) {
            currentOrder += ", ";
        }

        currentOrder += drinkName;

        editor.putString(KEY_ORDER, currentOrder);



        editor.apply();

        Toast.makeText(this, "Twoje zamówienie: " + drinkName, Toast.LENGTH_SHORT).show();
    }
}

