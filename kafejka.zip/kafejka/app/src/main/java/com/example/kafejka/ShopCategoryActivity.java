package com.example.kafejka;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class ShopCategoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_category);

        ArrayAdapter<Shop> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, Shop.shops);
        ListView listShops =(ListView) findViewById(R.id.list_shops);
        listShops.setAdapter(listAdapter);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View v, int position, long id) {
                Intent intent = new Intent(ShopCategoryActivity.this, ShopActivity.class);
                intent.putExtra(ShopActivity.EXTRA_SHOPID, (int) id);
                startActivity(intent);
            }
        };

        listShops.setOnItemClickListener(itemClickListener);
    }
}
