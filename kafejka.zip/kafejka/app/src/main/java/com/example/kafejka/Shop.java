package com.example.kafejka;

public class Shop {
    private String name;
    private String description;

    private int imageResourceId;
    public static final Shop[] shops = {
            new Shop("Warszawa", "ul. Zielona 6 \n Godziny otwarcia: \n poniedziałek - piątek: 09:00 - 17:30 \n sobota - niedziela: 10:00 - 18:00 ", R.drawable.shop),
            new Shop("Kraków", "ul. Katedralna 11 \n Godziny otwarcia: \n poniedziałek - piątek: 08:00 - 17:00 \n sobota - niedziela: 10:00 - 18:00 ", R.drawable.shop),
            new Shop("Gdańsk", "ul. Portowa 9a \n Godziny otwarcia: \n poniedziałek - piątek: 09:30 - 17:30 \n sobota - niedziela: 08:00 - 18:00 ", R.drawable.shop),
            new Shop("Sopot", "ul. Deptak 29 \n Godziny otwarcia: \n poniedziałek - piątek: 09:00 - 17:30 \n sobota: 08:00 - 18:00 \n niedziela: 10:00 - 16:00", R.drawable.shop)
    };

    private Shop(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }
    public String getDescription() {
        return description;
    }
    public String getName() {
        return name;
    }
    public int getImageResourceId() {
        return imageResourceId;
    }
    public String toString() {
        return this.name;
    }

}
