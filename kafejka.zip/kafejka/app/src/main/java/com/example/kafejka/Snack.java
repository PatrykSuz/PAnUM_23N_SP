package com.example.kafejka;

public class Snack {
    private String name;
    private String description;
    private int imageResourceId;

    public static final Snack[] snacks = {
            new Snack("Sernik", "Sernik baskijski z polewą z białej czekolady i orzechami.", R.drawable.sernik),
            new Snack("Szarlotka", "Klasyczna szarlotka z kruszonką i cynamonem.", R.drawable.szarlotka),
            new Snack("Muffinka", "Muffinki czyli babeczki z kawałkami belgijskiej białej i ciemnej czekolady.", R.drawable.muffina)
    };

    private Snack(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }
    public String getDescription() {
        return description;
    }
    public String getName() {
        return name;
    }
    public int getImageResourceId() {
        return imageResourceId;
    }
    public String toString() {
        return this.name;
    }
}
